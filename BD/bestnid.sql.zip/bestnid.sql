-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 16-07-2015 a las 05:05:12
-- Versión del servidor: 5.6.21
-- Versión de PHP: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `bestnid`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categoria`
--

CREATE TABLE IF NOT EXISTS `categoria` (
`idCategoria` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `descripcion` longtext
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `categoria`
--

INSERT INTO `categoria` (`idCategoria`, `nombre`, `descripcion`) VALUES
(3, 'ElectrodomÃ©sticos', 'Cualquier electrodomÃ©stico'),
(4, 'Otros', 'Cualquier producto que no estÃ© dentro de las otras categorias					'),
(9, 'Indumentaria', 'Cualquier tipo de indumentaria'),
(10, 'Muebles', 'Todo tipo de muebles, etc.'),
(11, 'Cocina', 'todo tipo de artÃ­culos de cocina, etc'),
(12, 'Celulares', 'Todo tipo de celulares'),
(13, 'Deportes ', 'todo tipo de artÃ­culos deportivos'),
(16, 'ComputaciÃ³n', 'Todo tipo de artÃ­culos informÃ¡ticos'),
(17, 'ElectrÃ³nica', 'ArtÃ­culos electrÃ³nicos');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comentario`
--

CREATE TABLE IF NOT EXISTS `comentario` (
`idComentario` int(11) NOT NULL,
  `texto` longtext NOT NULL,
  `idUsuario` int(11) NOT NULL,
  `idSubasta` int(11) DEFAULT NULL,
  `respuesta` longtext
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `comentario`
--

INSERT INTO `comentario` (`idComentario`, `texto`, `idUsuario`, `idSubasta`, `respuesta`) VALUES
(1, 'prueba comentario', 14, 35, 'prueba respuesta'),
(2, 'prueba comentario2', 24, 35, 'prueba respuesta2'),
(3, 'comentario psampras', 26, 35, NULL),
(4, 'comentario jiriarte', 21, 35, NULL),
(7, 'prueba comentario snake200', 14, 38, 'prueba respuesta a snake200'),
(8, 'comentario admin', 27, 38, 'respuesta comentario admin'),
(10, 'comentario snake200', 14, 39, 'respuesta comentario a snake200'),
(11, 'comentario estebanl', 64, 39, 'respuesta comentario estebanl'),
(13, 'comentario snake200', 14, 41, 'respues a snake200'),
(14, 'comentario ignaciogardey', 31, 38, 'respuesta comentario ignaciogardey'),
(15, 'comentario psampras', 26, 43, 'respuesta psampras'),
(16, 'comentario estebanl', 64, 41, 'respuesta estebanl'),
(19, 'comentario admin', 27, 41, 'respuesta admin'),
(20, 'comentario psampras', 26, 41, 'respuesta psampras'),
(21, 'comentario ignaciogardey', 31, 44, NULL),
(22, 'comentario ignaciongardey', 31, 36, NULL),
(23, 'comentario admin', 27, 45, 'respuesta admin'),
(24, 'comentario snake200', 14, 44, 'respuesta snake200'),
(27, 'comentario jcgardey', 29, 41, 'respuesta jcgardey'),
(29, 'comentario rafanadal', 30, 44, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `configuracion`
--

CREATE TABLE IF NOT EXISTS `configuracion` (
`idClave` int(11) NOT NULL,
  `clave` varchar(60) NOT NULL,
  `valor` varchar(60) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `configuracion`
--

INSERT INTO `configuracion` (`idClave`, `clave`, `valor`) VALUES
(1, 'administrador', 'admin'),
(2, 'porcentaje', '20'),
(3, 'duracion_maxima', '10'),
(4, 'tiempoLimiteElegirGanador', '7');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mensaje`
--

CREATE TABLE IF NOT EXISTS `mensaje` (
`idMensaje` int(11) NOT NULL,
  `mensaje` longtext NOT NULL,
  `respuesta` longtext,
  `idUsuario` int(11) NOT NULL,
  `leido` tinyint(1) NOT NULL DEFAULT '0',
  `fecha` date NOT NULL,
  `respuestaLeida` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `mensaje`
--

INSERT INTO `mensaje` (`idMensaje`, `mensaje`, `respuesta`, `idUsuario`, `leido`, `fecha`, `respuestaLeida`) VALUES
(1, 'prueba de mensaje al administrador snake200', 'respuesta a snake200', 14, 1, '2015-07-11', 1),
(2, 'otro mensaje al administrador', 'respuesta a otro mensaje', 14, 1, '2015-07-11', 1),
(3, 'consulta jcgardey', 'respuesta jcgardey', 29, 1, '2015-07-11', 1),
(4, 'mensaje rafanadal', 'respuesta rafanadal', 30, 1, '2015-07-11', 1),
(5, 'mensaje rafanadal 2', 'respuesta rafanadal2', 30, 1, '2015-07-11', 1),
(6, 'consulta jcgardey 2', 'respuesta jcgardey2', 29, 1, '2015-07-11', 1),
(7, 'consulta 3', 'respuesta jcgardey3', 29, 1, '2015-07-11', 1),
(8, 'consulta jcgardey 4', 'respuesta jcgardey4', 29, 1, '2015-07-11', 1),
(9, 'consulta 4 jcgardey', 'respuesta 4 jcgardey', 29, 1, '2015-07-11', 1),
(10, 'mensaje 3 snake200', 'respuesta 3 snake200', 14, 1, '2015-07-11', 1),
(11, 'mensaje 1 vestrella', 'respuesta 1 vestrella', 24, 1, '2015-07-11', 1),
(12, 'mensaje 2 vestrella', 'respuesta 2 vestrella', 24, 1, '2015-07-11', 1),
(13, 'consulta 5 jcgardey', 'respuesta consulta 5 jcgardey', 29, 1, '2015-07-11', 1),
(14, 'mensaje 1 ignaciogardey', 'respuesta mensaje 1 ignaciogardey', 31, 1, '2015-07-11', 1),
(15, 'mensaje 1 itempo', 'respuesta 1 itempo', 23, 1, '2015-07-11', 1),
(16, 'mensaje 2 ignaciogardey', 'respuesta 2 ignaciogardey', 31, 1, '2015-07-13', 1),
(17, 'mensaje 3 ignaciogardey', 'respuesta 3 ignaciogardey', 31, 1, '2015-07-13', 1),
(18, 'mensaje 4 snake200', 'respuesta 4 snake200', 14, 1, '2015-07-15', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `oferta`
--

CREATE TABLE IF NOT EXISTS `oferta` (
`idOferta` int(11) NOT NULL,
  `razon` longtext NOT NULL,
  `monto` bigint(20) NOT NULL,
  `fecha` date NOT NULL,
  `idUsuario` int(11) NOT NULL,
  `idSubasta` int(11) DEFAULT NULL,
  `reportada` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=172 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `oferta`
--

INSERT INTO `oferta` (`idOferta`, `razon`, `monto`, `fecha`, `idUsuario`, `idSubasta`, `reportada`) VALUES
(5, 'soy coleccionista de pelotas', 100, '2015-06-01', 28, 11, 0),
(6, 'Necesito una mesa para la cocina', 40, '2015-06-02', 15, 7, 0),
(7, 'Necesito un escritorio', 500, '2015-06-03', 16, 7, 0),
(8, 'la que tengo quedo chica', 200, '2015-06-03', 23, 7, 0),
(9, 'Se me pinchÃ³ mi pelota', 100, '2015-06-03', 15, 10, 0),
(10, 'Quiero decorar mi casa', 600, '2015-06-03', 15, 11, 0),
(12, 'Necesito hacer un regalo', 200, '2015-06-03', 21, 10, 0),
(14, 'Tenia una pelota igual', 1000, '2015-06-03', 27, 10, 0),
(15, 'Me robaron un televisor de mi casa', 200, '2015-06-03', 23, 13, 0),
(16, 'Otra necesidad', 300, '2015-06-03', 28, 10, 0),
(17, 'Tengo una igual y necesito otra mas', 900, '2015-06-03', 27, 14, 0),
(19, 'Se quemÃ³ el que tenia en mi casa', 600, '2015-06-03', 26, 15, 0),
(20, 'Wilson me rescindiÃ³ el contrato y no tengo raqueta', 1000, '2015-06-03', 26, 14, 0),
(21, 'se me quemÃ³ el LED de 50 pulgadas de mi casa', 150, '2015-06-03', 26, 13, 0),
(23, 'una necesidad', 1000, '2015-06-03', 24, 14, 0),
(24, 'Necesito un microondas para regalar', 500, '2015-06-03', 24, 15, 0),
(25, 'necesidad 1', 10000, '2015-06-03', 24, 16, 0),
(26, 'necesito un televisor que reproduzca 4k', 90, '2015-06-03', 24, 13, 0),
(30, 'necesidad 5', 675, '2015-06-03', 29, 15, 0),
(31, 'Estoy podrido de tener que descongelar mi heladera', 5000, '2015-06-03', 29, 16, 0),
(34, ' rafanecesida rafa rafanecesida rafa rafanecesida rafa rafanecesida rafa rafanecesida rafa rafanecesida rafa rafanecesida rafa rafanecesida rafa rafanecesida rafa rafanecesida rafa rafanecesida rafa rafanecesida rafa rafanecesida rafa rafanecesida rafa rafanecesida rafa rafanecesida rafa rafanecesida rafa rafanecesida rafa rafanecesida rafa rafanecesida rafa rafanecesida rafa rafanecesida rafa rafanecesida rafa rafanecesida rafa rafanecesida rafa rafanecesida rafa rafanecesida rafa rafanecesida rafa', 15000, '2015-06-05', 30, 16, 0),
(35, ' rafanecesida rafa rafanecesida rafa rafanecesida rafa rafanecesida rafa rafanecesida rafa rafanecesida rafa rafanecesida rafa rafanecesida rafa rafanecesida rafa rafanecesida rafa', 500, '2015-06-05', 30, 15, 0),
(36, 'necesidad snake', 5000, '2015-06-05', 14, 16, 0),
(38, 'necesidad 1', 100, '2015-06-05', 14, 19, 0),
(39, 'necesidad 2', 150, '2015-06-05', 24, 19, 0),
(40, 'necesidad', 100, '2015-06-06', 14, 20, 0),
(41, 'necesidad admin', 10000, '2015-06-06', 27, 21, 0),
(42, 'necesidad snake', 20000, '2015-06-06', 14, 21, 0),
(43, 'necesidad jcgardey', 500, '2015-06-06', 29, 21, 0),
(44, 'se me quemo la que tenia', 100, '2015-06-06', 29, 22, 0),
(45, 'necesidad snake', 130, '2015-06-06', 14, 22, 0),
(47, 'necesidad vestrella', 8000, '2015-06-06', 24, 24, 0),
(49, 'necesidad itempo', 6000, '2015-06-06', 23, 24, 0),
(51, 'necesidad ignaciogardey', 7500, '2015-06-06', 31, 24, 0),
(53, 'necesidad ignaciogardey', 220, '2015-06-06', 31, 22, 0),
(54, 'necesidad jiriarte', 200, '2015-06-06', 21, 27, 0),
(55, 'necesidad jiriarte', 110, '2015-06-06', 21, 22, 0),
(57, 'necesidad jiriarte', 1000, '2015-06-06', 21, 26, 0),
(58, 'necesidad snake200', 3000, '2015-06-06', 14, 26, 0),
(59, 'necesidad snake200', 250, '2015-06-06', 14, 27, 0),
(60, 'necesidad itempo', 180, '2015-06-06', 23, 27, 0),
(61, 'necesidad itempo', 140, '2015-06-06', 23, 22, 0),
(62, 'necesidad itempo', 90, '2015-06-06', 23, 28, 0),
(64, 'necesidad rafanadal', 135, '2015-06-06', 30, 27, 0),
(65, 'necesidad rafanadal', 4500, '2015-06-06', 30, 24, 0),
(66, 'necesidad rafanadal', 3500, '2015-06-06', 30, 26, 0),
(69, 'necesidad rafanadal', 80, '2015-06-06', 30, 28, 0),
(71, 'necesidad snake200', 160, '2015-06-06', 14, 28, 0),
(72, 'necesidad vestrella', 100, '2015-06-06', 24, 27, 0),
(73, 'necesidad vestrella', 5000, '2015-06-06', 24, 26, 0),
(74, 'necesidad vestrella', 300, '2015-06-06', 24, 22, 0),
(75, 'necesidad vestrella', 200, '2015-06-06', 24, 28, 0),
(76, 'necesidad ignaciogardey', 3800, '2015-06-06', 31, 26, 0),
(77, 'necesidad ignaciogardey', 60, '2015-06-06', 31, 28, 0),
(85, 'necesidad vestrella', 100, '2015-06-22', 24, 35, 0),
(90, 'necesidad snake200', 10000, '2015-06-26', 14, 38, 0),
(91, 'necesidad admin', 5000, '2015-06-26', 27, 38, 0),
(92, 'oferta admin', 10, '2015-06-26', 27, 36, 0),
(94, 'necesidad snake200', 300, '2015-06-26', 14, 39, 0),
(95, 'necesidad estebanl', 500, '2015-06-26', 64, 39, 0),
(97, 'necesidad estebanl', 2000, '2015-06-26', 64, 38, 0),
(99, 'necesidad psampras', 300, '2015-06-26', 26, 43, 0),
(102, 'necesidad ignaciogardey', 2000, '2015-06-26', 31, 44, 0),
(104, 'necesidad ignaciogardey', 40, '2015-06-26', 31, 36, 0),
(105, 'necesidad admin', 300, '2015-06-26', 27, 45, 0),
(107, 'necesidad admin', 5000, '2015-06-26', 27, 41, 0),
(109, 'necesidad snake200', 250, '2015-06-27', 14, 45, 0),
(111, 'necesidad snake200', 4700, '2015-06-27', 14, 44, 0),
(113, 'necesidad jcgardey', 7000, '2015-06-27', 29, 44, 0),
(117, 'necesidad jcgardey', 200, '2015-06-27', 29, 45, 0),
(118, 'necesidad jcgardey ', 4100, '2015-06-27', 29, 41, 0),
(121, 'necesidad rafanadal', 6500, '2015-06-27', 30, 44, 0),
(123, 'necesidad rafanadal', 3000, '2015-06-27', 30, 41, 0),
(138, 'necesidad jcgardey', 400, '2015-07-08', 29, 55, 0),
(141, 'necesidad vestrella', 360, '2015-07-08', 24, 52, 0),
(142, 'necesidad vestrella', 200, '2015-07-08', 24, 55, 0),
(144, 'necesidad ignaciogardey', 272, '2015-07-08', 31, 52, 0),
(146, 'necesidad rafanadal', 230, '2015-07-08', 30, 52, 0),
(147, 'necesidad itempo', 200, '2015-07-08', 23, 52, 0),
(152, 'necesidad jcgardey', 5600, '2015-07-08', 29, 59, 0),
(153, 'necesidad psampras', 3500, '2015-07-08', 26, 59, 0),
(154, 'Mi necesidad', 3000, '2015-07-12', 29, 60, 0),
(155, 'necesidad ignaciogardey', 4500, '2015-07-12', 31, 60, 0),
(156, 'necesidad snake200', 4100, '2015-07-12', 14, 60, 0),
(157, 'necesidad ignaciogardey', 6700, '2015-07-12', 31, 62, 0),
(158, 'necesidad snake200', 5700, '2015-07-13', 14, 62, 0),
(162, 'necesidad jcgardey', 10000, '2015-07-15', 29, 62, 0),
(163, 'necesidad jcgardey', 1700, '2015-07-15', 29, 61, 0),
(165, 'necesidad snake200', 320, '2015-07-15', 14, 66, 0),
(168, 'necesidad snake200', 450, '2015-07-15', 14, 65, 0),
(169, 'necesidad snake200', 1500, '2015-07-15', 14, 61, 0),
(170, 'necesidad itempo', 300, '2015-07-15', 23, 66, 1),
(171, 'necesidad jcgardey ', 340, '2015-07-15', 29, 66, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE IF NOT EXISTS `producto` (
`idProducto` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `descripcion` longtext,
  `idCategoria` int(11) NOT NULL,
  `imagen` varchar(100) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `producto`
--

INSERT INTO `producto` (`idProducto`, `nombre`, `descripcion`, `idCategoria`, `imagen`) VALUES
(8, 'mesa', 'mesa de madera', 4, 'Imagenes/mesa.JPG'),
(9, 'logo bestnid', 'logo de la Empresa Bestnid', 4, 'Imagenes/logo.png'),
(10, 'cuadro', 'cuadro de paisaje', 4, 'Imagenes/paisaje_verde.jpg'),
(11, 'pelota de futbol', 'pelota de futbol adidas impecable', 4, 'Imagenes/pelota adidas.png'),
(12, 'Balon de oro', 'Balon de oro temporada 2011', 4, 'Imagenes/balon de oro.PNG'),
(13, 'prueba', 'prueba con imagen alta', 4, 'Imagenes/imagen_alta.jpg'),
(14, 'televisor', 'televisor antigÃ¼o de 20 pulgadas', 4, 'Imagenes/televisor.jpg'),
(15, 'raqueta de tenis', 'descripcion largadescripcion largadescripcion largadescripcion largadescripcion largadescripcion largadescripcion largadescripcion largadescripcion largadescripcion largadescripcion largadescripcion largadescripcion largadescripcion largadescripcion largadescripcion largadescripcion largadescripcion largadescripcion largadescripcion largadescripcion largadescripcion largadescripcion largadescripcion largadescripcion largadescripcion largadescripcion largadescripcion largadescripcion largadescripcion larga', 4, 'Imagenes/raqueta de tenis.jpg'),
(16, 'microondas', 'microondas nuevo con botones marca whirpool', 4, 'Imagenes/microondas.jpg'),
(17, 'heladera', 'heladera nueva heladera nueva heladera nueva heladera nueva heladera nueva heladera nueva heladera nueva heladera nueva heladera nueva heladera nueva heladera nueva heladera nueva heladera nueva heladera nueva heladera nueva heladera nueva heladera nueva heladera nueva heladera nueva heladera nueva heladera nueva heladera nueva heladera nueva heladera nueva heladera nueva heladera nueva heladera nueva heladera nueva heladera nueva heladera nueva heladera nueva heladera nueva heladera nueva heladera nueva heladera nueva heladera nueva ', 3, 'Imagenes/heladera.jpg'),
(19, 'televisor LED', 'televisor LED sony 40 pulgadas', 4, 'Imagenes/led sony.png'),
(20, 'celular nokia 1100', 'nokia 110 nuevo ', 12, 'Imagenes/nokia 1100.jpg'),
(21, 'ipad', 'ipad 3', 4, 'Imagenes/ipad 3.jpg'),
(22, 'galaxy S5', 'impecable', 12, 'Imagenes/galaxy s5.jpg'),
(23, 'olla ', 'olla de acero inoxidable', 11, 'Imagenes/olla.png'),
(24, 'cama ', 'cama de dos plazas', 10, 'Imagenes/cama.png'),
(25, 'play station 4', 'play station 4 muy poco uso', 4, 'Imagenes/ps4.jpg'),
(26, 'repisa', 'repisa de madera poco uso', 10, 'Imagenes/repisa.jpg'),
(27, 'estereo', 'estereo de gran potencia marca sony', 4, 'Imagenes/estereo.jpg'),
(28, 'remera', 'remera de tenis Adidas nueva', 9, 'Imagenes/remera adidas.jpg'),
(29, 'pava elÃ©ctrica', 'pava elÃ©ctrica phillips', 3, 'Imagenes/pava electrica.jpg'),
(30, 'buzo', 'buzo de algodon adidas', 9, 'Imagenes/buzo adidas.jpg'),
(31, 'camiseta Juventus', 'camiseta de la temporada 2015', 13, 'Imagenes/camiseta juventus.jpg'),
(34, 'platos', 'platos impecables', 11, 'Imagenes/platos.png'),
(35, 'horno electrico', 'horno', 11, 'Imagenes/horno electrico.jpg'),
(36, 'pelota', 'pelota adidas', 13, 'Imagenes/pelota adidas.png'),
(37, 'DER Bestnid', 'diagrama entidad relaciÃ³n', 4, 'Imagenes/DER BESTNID.png'),
(38, 'router', 'router TPLINK', 4, 'Imagenes/router.jpg'),
(39, 'macbook', 'apple macbook air ', 4, 'Imagenes/macbook.png'),
(40, 'reproductor de DVD', 'reproductor de DVD impecable', 17, 'Imagenes/reproductor dvd.jpg'),
(42, 'lavarropas', 'Lavarropas marca Drean nuevo', 3, 'Imagenes/lavarropas.jpg'),
(43, 'placa de video', 'placa de video nvidia geforce titan z', 16, 'Imagenes/placa de video.jpg'),
(44, 'sega ', 'sega gÃ©nesis 3', 17, 'Imagenes/sega.jpg'),
(45, 'iphone 6', 'iphone 6 nuevo', 12, 'Imagenes/iphone.jpg'),
(46, 'pelota de basket', 'pelota de basket molten', 13, 'Imagenes/basket.jpg'),
(55, 'maquina de cafe ', 'maquina de cafe nueva', 3, 'Imagenes/maquina de cafe.jpg'),
(58, 'camiseta argentina', 'camiseta SelecciÃ³n Argentina 2015', 9, 'Imagenes/camiseta argentina.jpg'),
(62, 'bicicleta de carrera', 'bicicleta de carrera nueva', 13, 'Imagenes/bicicleta de carrera.jpg'),
(63, 'cocina whirpool', 'cocina whipool nueva', 11, 'Imagenes/cocina.jpg'),
(64, 'estereo de automÃ³vil', 'estereo de automÃ³vil marca sony    ', 17, 'Imagenes/autoestereo sony.jpg'),
(65, 'xbox 720', 'xbox 720 impecable poco uso', 17, 'Imagenes/Xbox.png'),
(68, 'mesa de luz', 'mesa de luz nueva', 10, 'Imagenes/mesa de luz.jpg'),
(69, 'pelota de rugby', 'pelota de rugby Gilbert', 13, 'Imagenes/pelota rugby.jpg'),
(71, 'camiseta del real madrid', 'camiseta real madrid temporada 2015/2016', 13, 'Imagenes/camiseta real madrid.jpg'),
(72, 'celular moto g', 'celular motorola moto g', 12, 'Imagenes/moto g.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `subasta`
--

CREATE TABLE IF NOT EXISTS `subasta` (
`idSubasta` int(11) NOT NULL,
  `idUsuario` int(11) NOT NULL,
  `estado` varchar(50) NOT NULL,
  `fecha_cierre` date NOT NULL,
  `idProducto` int(11) DEFAULT NULL,
  `fecha_realizacion` date NOT NULL,
  `reportada` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `subasta`
--

INSERT INTO `subasta` (`idSubasta`, `idUsuario`, `estado`, `fecha_cierre`, `idProducto`, `fecha_realizacion`, `reportada`) VALUES
(7, 14, 'cerrada', '2015-05-06', 8, '0000-00-00', 0),
(8, 14, 'cerrada', '2015-06-06', 9, '0000-00-00', 0),
(9, 14, 'cerrada', '2015-04-06', 10, '0000-00-00', 0),
(10, 14, 'cerrada', '2015-06-03', 11, '2015-05-30', 0),
(11, 14, 'cerrada', '2015-06-03', 12, '2015-05-30', 0),
(13, 27, 'cerrada', '2015-06-04', 14, '2015-06-03', 0),
(14, 23, 'cerrada', '2015-06-04', 15, '2015-06-03', 0),
(15, 27, 'cerrada', '2015-06-05', 16, '2015-06-03', 0),
(16, 26, 'cerrada', '2015-06-05', 17, '2015-06-03', 0),
(18, 30, 'cerrada', '2015-06-05', 19, '2015-06-05', 0),
(19, 27, 'cerrada', '2015-06-05', 20, '2015-06-05', 0),
(20, 27, 'cerrada', '2015-06-06', 21, '2015-06-06', 0),
(21, 26, 'cerrada', '2015-06-06', 22, '2015-06-06', 0),
(22, 30, 'cerrada', '2015-06-07', 23, '2015-06-06', 0),
(23, 29, 'cerrada', '2015-06-07', 24, '2015-06-06', 0),
(24, 14, 'cerrada', '2015-06-06', 25, '2015-06-06', 0),
(26, 23, 'cerrada', '2015-06-06', 27, '2015-06-06', 0),
(27, 31, 'cerrada', '2015-06-06', 28, '2015-06-06', 0),
(28, 21, 'cerrada', '2015-06-06', 29, '2015-06-06', 0),
(29, 21, 'cerrada', '2015-06-07', 30, '2015-06-06', 0),
(30, 14, 'cerrada', '2015-06-08', 31, '2015-06-06', 0),
(33, 14, 'cerrada', '2015-06-17', 34, '2015-06-17', 0),
(35, 27, 'cerrada', '2015-06-13', 36, '2015-06-10', 0),
(36, 14, 'cerrada', '2015-06-10', 37, '2015-06-01', 0),
(38, 26, 'cerrada', '2015-06-26', 39, '2015-06-26', 0),
(39, 27, 'cerrada', '2015-06-26', 40, '2015-06-25', 0),
(41, 31, 'cerrada', '2015-07-02', 42, '2015-06-26', 0),
(42, 14, 'cerrada', '2015-06-16', 43, '2015-06-10', 0),
(43, 64, 'cerrada', '2015-06-10', 44, '2015-06-06', 0),
(44, 27, 'cerrada', '2015-06-27', 45, '2015-06-26', 0),
(45, 31, 'cerrada', '2015-06-27', 46, '2015-06-26', 0),
(52, 29, 'cerrada', '2015-07-08', 55, '2015-07-06', 0),
(55, 14, 'cerrada', '2015-07-08', 58, '2015-07-06', 0),
(59, 14, 'cerrada', '2015-07-09', 62, '2015-07-08', 0),
(60, 30, 'cerrada', '2015-07-12', 63, '2015-07-12', 0),
(61, 31, 'activa', '2015-07-17', 64, '2015-07-12', 0),
(62, 26, 'finalizada', '2015-07-16', 65, '2015-07-12', 0),
(65, 21, 'activa', '2015-07-22', 68, '2015-07-15', 0),
(66, 30, 'cerrada', '2015-07-15', 69, '2015-07-15', 0),
(68, 29, 'activa', '2015-07-20', 71, '2015-07-15', 0),
(69, 23, 'activa', '2015-07-20', 72, '2015-07-15', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE IF NOT EXISTS `usuario` (
`idUsuario` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `apellido` varchar(100) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `numero_calle` varchar(10) NOT NULL,
  `nombre_usuario` varchar(15) NOT NULL,
  `password` varchar(20) NOT NULL,
  `e_mail` varchar(50) NOT NULL,
  `confirmado` tinyint(1) NOT NULL,
  `estado` varchar(50) NOT NULL,
  `piso` varchar(1) DEFAULT NULL,
  `depto` varchar(1) DEFAULT NULL,
  `calle` varchar(20) NOT NULL,
  `codigoActivacion` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`idUsuario`, `nombre`, `apellido`, `telefono`, `numero_calle`, `nombre_usuario`, `password`, `e_mail`, `confirmado`, `estado`, `piso`, `depto`, `calle`, `codigoActivacion`) VALUES
(14, 'Juan Cruz', 'Gardey', '02923650033', '723', 'snake200', 'Juan123', 'juancruzgardey@hotmail.com', 1, 'activo', '', '', '50', '970f294a2c1715d0096e9361ad14f37b'),
(15, 'Juan', 'Filameno', '02923698271', '543', 'juanf', 'Juanf12', 'juanf@hotmail.com', 1, 'activo', '', '', '45', '53ba69d748cb93e5a54ea9e575a21ddb'),
(16, 'ariel', 'sobrado', '02923698271', '1', 'asobrado', 'Adminadmin1', 'asobrado@gmail.com', 1, 'activo', '1', 'w', 'q', '47b106e8d53040985872f9c51012191c'),
(21, 'Juan', 'Iriarte', '02923698271', '723', 'jiriarte', 'Juan123', 'juancruzgardey@gmail.com', 1, 'activo', '6', 'B', '60', 'a0fa4b1f97a680d06cae32852dfa8582'),
(23, 'Ignacio', 'Tempo', '02922465011', '456', 'itempo', 'Itempo123', 'ignaciot@gmail.com', 1, 'activo', '', '', 'EspaÃ±a', 'c7f0d44216e16269dc57c9f901cf2b1b'),
(24, 'Victor', 'Estrella', '02923698271', '8', 'vestrella', 'Vestrella123', 'victore@hotmail.com', 1, 'activo', '2', 'C', '450', 'ab4c4c8fc28715e09125b3249cd87d22'),
(26, 'Pete ', 'Sampras', '0291235467', '768', 'psampras', 'Pete123', 'pete@yahoo.com', 1, 'activo', '2', 'A', '2', 'ac843c37a45573ccfaa1257032704f01'),
(27, 'David', 'Nalbandian', '02922465011', '270', 'admin', 'David123', 'davidN@yahoo.com', 1, 'activo', '', '', 'Pellegrini', '059ca5c8075663de661a3ec9ba85248e'),
(28, 'virginia', 'bertuzzi', '2923416328', '518', 'virginiabertuzz', 'Virginiabertuzzi1!', 'virgibertuzzi@gmail.com', 0, 'activo', '1', 'E', '47', '62b29003560751dad560358b2cabddfd'),
(29, 'Juan Carlos', 'Gardey', '02922465011', '709', 'jcgardey', 'Juanc123', 'gardeyjuanc@speedy.com.ar', 1, 'activo', '', '', 'Italia', 'c891ca9b4723360d649d84a3f4c5101b'),
(30, 'Rafael', 'Nadal', '02922465594', '500', 'rafanadal', 'Rafael123', 'ignaciogardey@hotmail.com', 1, 'activo', '1', '2', 'Francia', '7e23dfcc78b5773ace30e8beb85c85e8'),
(31, 'Juan Ignacio', 'Gardey', '2922465060', '600', 'ignaciogardey', 'Ignacio123', 'ignaciogardey@hotmail.com', 1, 'activo', '', '', '53', 'a0ae4ddbe8ab251b44ec38fbfcd00484'),
(64, 'Esteban', 'Lambda', '02923698276', '723', 'estebanl', 'Esteban123', 'juancruzgardey@hotmail.com', 1, 'activo', '', '', '60', 'f36e2306d6658419a501bf9949f9912c'),
(65, 'Roberto', 'Fresta', '02923698276', '723', 'rfresta', 'Roberto123', 'juancruzgardey@hotmail.com', 1, 'activo', '', '', '60', '6d915e64f5b8192e26be062173e2e33f');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `venta`
--

CREATE TABLE IF NOT EXISTS `venta` (
`idVenta` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `porcentaje` int(11) NOT NULL,
  `idOferta` int(11) DEFAULT NULL,
  `ofertaPagada` tinyint(1) NOT NULL DEFAULT '0',
  `comisionPagada` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `venta`
--

INSERT INTO `venta` (`idVenta`, `fecha`, `porcentaje`, `idOferta`, `ofertaPagada`, `comisionPagada`) VALUES
(1, '2015-06-03', 15, 7, 0, 0),
(2, '2015-06-03', 15, 12, 1, 0),
(4, '2015-06-03', 15, 10, 0, 0),
(6, '2015-06-04', 15, 17, 0, 0),
(7, '2015-06-04', 15, 26, 0, 0),
(12, '2015-06-06', 15, 40, 0, 0),
(13, '2015-06-06', 15, 43, 0, 0),
(14, '2015-06-06', 15, 57, 0, 0),
(15, '2015-06-06', 15, 69, 0, 0),
(16, '2015-06-06', 15, 47, 0, 1),
(18, '2015-06-26', 30, 95, 0, 0),
(19, '2015-06-26', 30, 90, 0, 0),
(20, '2015-06-27', 45, 117, 0, 0),
(21, '2015-07-08', 45, 147, 0, 0),
(22, '2015-07-08', 45, 142, 1, 1),
(23, '2015-07-09', 45, 152, 1, 1),
(24, '2015-07-12', 45, 154, 0, 1),
(25, '2015-07-15', 20, 171, 0, 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categoria`
--
ALTER TABLE `categoria`
 ADD PRIMARY KEY (`idCategoria`), ADD UNIQUE KEY `nombre` (`nombre`);

--
-- Indices de la tabla `comentario`
--
ALTER TABLE `comentario`
 ADD PRIMARY KEY (`idComentario`), ADD KEY `idUsuario` (`idUsuario`), ADD KEY `comentario_ibfk_2` (`idSubasta`);

--
-- Indices de la tabla `configuracion`
--
ALTER TABLE `configuracion`
 ADD PRIMARY KEY (`idClave`);

--
-- Indices de la tabla `mensaje`
--
ALTER TABLE `mensaje`
 ADD PRIMARY KEY (`idMensaje`), ADD KEY `idUsuario` (`idUsuario`);

--
-- Indices de la tabla `oferta`
--
ALTER TABLE `oferta`
 ADD PRIMARY KEY (`idOferta`), ADD KEY `idUsuario` (`idUsuario`), ADD KEY `oferta_ibfk_2` (`idSubasta`);

--
-- Indices de la tabla `producto`
--
ALTER TABLE `producto`
 ADD PRIMARY KEY (`idProducto`), ADD KEY `idCategoria` (`idCategoria`);

--
-- Indices de la tabla `subasta`
--
ALTER TABLE `subasta`
 ADD PRIMARY KEY (`idSubasta`), ADD KEY `idUsuario` (`idUsuario`), ADD KEY `subasta_ibfk_2_idx` (`idProducto`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
 ADD PRIMARY KEY (`idUsuario`), ADD UNIQUE KEY `nombre_usuario` (`nombre_usuario`);

--
-- Indices de la tabla `venta`
--
ALTER TABLE `venta`
 ADD PRIMARY KEY (`idVenta`), ADD UNIQUE KEY `idOferta_UNIQUE` (`idOferta`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `categoria`
--
ALTER TABLE `categoria`
MODIFY `idCategoria` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT de la tabla `comentario`
--
ALTER TABLE `comentario`
MODIFY `idComentario` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT de la tabla `configuracion`
--
ALTER TABLE `configuracion`
MODIFY `idClave` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de la tabla `mensaje`
--
ALTER TABLE `mensaje`
MODIFY `idMensaje` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT de la tabla `oferta`
--
ALTER TABLE `oferta`
MODIFY `idOferta` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=172;
--
-- AUTO_INCREMENT de la tabla `producto`
--
ALTER TABLE `producto`
MODIFY `idProducto` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=73;
--
-- AUTO_INCREMENT de la tabla `subasta`
--
ALTER TABLE `subasta`
MODIFY `idSubasta` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=70;
--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
MODIFY `idUsuario` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=66;
--
-- AUTO_INCREMENT de la tabla `venta`
--
ALTER TABLE `venta`
MODIFY `idVenta` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=26;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `comentario`
--
ALTER TABLE `comentario`
ADD CONSTRAINT `comentario_ibfk_1` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `comentario_ibfk_2` FOREIGN KEY (`idSubasta`) REFERENCES `subasta` (`idSubasta`) ON DELETE SET NULL ON UPDATE NO ACTION;

--
-- Filtros para la tabla `mensaje`
--
ALTER TABLE `mensaje`
ADD CONSTRAINT `mensaje_ibfk_1` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `oferta`
--
ALTER TABLE `oferta`
ADD CONSTRAINT `oferta_ibfk_1` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `oferta_ibfk_2` FOREIGN KEY (`idSubasta`) REFERENCES `subasta` (`idSubasta`) ON DELETE SET NULL ON UPDATE NO ACTION;

--
-- Filtros para la tabla `producto`
--
ALTER TABLE `producto`
ADD CONSTRAINT `producto_ibfk_2` FOREIGN KEY (`idCategoria`) REFERENCES `categoria` (`idCategoria`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `subasta`
--
ALTER TABLE `subasta`
ADD CONSTRAINT `subasta_ibfk_1` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `subasta_ibfk_2` FOREIGN KEY (`idProducto`) REFERENCES `producto` (`idProducto`) ON DELETE SET NULL ON UPDATE NO ACTION;

--
-- Filtros para la tabla `venta`
--
ALTER TABLE `venta`
ADD CONSTRAINT `venta_ibfk_1` FOREIGN KEY (`idOferta`) REFERENCES `oferta` (`idOferta`) ON DELETE CASCADE ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
